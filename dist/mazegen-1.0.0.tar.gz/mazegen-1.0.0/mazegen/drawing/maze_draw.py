# maze_draw.py
import curses
from typing import Any, List, Optional, Tuple

# ---------- Characters ----------
WALL_CHAR = '█'
PATH_CHAR = ' '
ENTRY_CHAR = 'E'
EXIT_CHAR = 'X'
SOLUTION_CHAR = '☀'

# ---------- Header ----------
HEADER_TEXT = "★ THE AMAZING MAZE ENGINE ★"

# ---------- Color Themes ----------
# ---------- Color Themes ----------
# Format: (walls, entry, exit, solution, highlight)
COLOR_THEMES: List[Tuple[int, int, int, int, int]] = [
    (
        curses.COLOR_WHITE,
        curses.COLOR_GREEN,
        curses.COLOR_RED,
        curses.COLOR_CYAN,
        curses.COLOR_MAGENTA,
    ),
    (
        curses.COLOR_GREEN,
        curses.COLOR_GREEN,
        curses.COLOR_RED,
        curses.COLOR_CYAN,
        curses.COLOR_MAGENTA,
    ),
    (
        curses.COLOR_YELLOW,
        curses.COLOR_GREEN,
        curses.COLOR_RED,
        curses.COLOR_CYAN,
        curses.COLOR_MAGENTA,
    ),
    (
        curses.COLOR_RED,
        curses.COLOR_GREEN,
        curses.COLOR_RED,
        curses.COLOR_CYAN,
        curses.COLOR_MAGENTA,
    ),
    (
        curses.COLOR_CYAN,
        curses.COLOR_GREEN,
        curses.COLOR_RED,
        curses.COLOR_CYAN,
        curses.COLOR_MAGENTA,
    ),
]

current_theme: int = 0  # Keep track of current theme

# ---------- Safe Draw Helper ----------


def safe_addstr(stdscr: Any, y: int, x: int, text: str, attr: int = 0) -> None:
    """
    Draw text safely inside terminal bounds to avoid curses errors.

    Args:
        stdscr: curses window object
        y: row position
        x: column position
        text: string to display
        attr: curses attributes (color, bold, etc.)
    """
    term_h, term_w = stdscr.getmaxyx()
    if 0 <= y < term_h and 0 <= x < term_w:
        try:
            stdscr.addstr(y, x, text, attr)
        except curses.error:
            pass

# ---------- Theme Functions ----------


def apply_theme() -> None:
    """
    Initialize curses color pairs based on the current theme.

    Color pair numbers:
        1 → Wall
        2 → Entry
        3 → Exit
        4 → Solution
        5 → Highlight / special blocks
    """
    wall, entry, exitc, solution, highlight = COLOR_THEMES[current_theme]
    curses.init_pair(1, wall, -1)
    curses.init_pair(2, entry, -1)
    curses.init_pair(3, exitc, -1)
    curses.init_pair(4, solution, -1)
    curses.init_pair(5, highlight, -1)


def rotate_theme() -> None:
    """Rotate to the next theme and apply it."""
    global current_theme
    current_theme = (current_theme + 1) % len(COLOR_THEMES)
    apply_theme()


# ---------- Solution Path Helper ----------


def _solution_screen_positions(
    solution: List[Tuple[int, int]]
) -> List[Tuple[int, int]]:
    """
    Convert maze solution coordinates into screen positions.

    Includes intermediate corridor cells between consecutive maze cells so
    that the drawn path appears fully connected rather than dotted.

    Args:
        solution: list of (x, y) maze cell coordinates

    Returns:
        List of (screen_y, screen_x) positions covering the full path.
    """
    positions: List[Tuple[int, int]] = []
    for i, (x, y) in enumerate(solution):
        positions.append((2 * y + 1, 2 * x + 1))
        if i + 1 < len(solution):
            nx, ny = solution[i + 1]
            # Corridor cell that sits between the two adjacent maze cells on
            # screen.  Consecutive solution cells are always neighbours so the
            # midpoint formula below is exact and produces an integer result.
            corridor_y = (2 * y + 1 + 2 * ny + 1) // 2  # == y + ny + 1
            corridor_x = (2 * x + 1 + 2 * nx + 1) // 2  # == x + nx + 1
            positions.append((corridor_y, corridor_x))
    return positions


# ---------- Maze Drawing ----------
def draw_cell(stdscr: Any, maze: List[List[int]], y: int, x: int) -> None:
    """
    Draw a single maze cell and carve open walls.

    Args:
        stdscr: curses window object
        maze: 2D list of maze cells
        y: row index in maze
        x: column index in maze
    """
    cell = maze[y][x]
    screen_y = 2 * y + 1
    screen_x = 2 * x + 1

    # Empty path
    safe_addstr(stdscr, screen_y, screen_x, PATH_CHAR)

    # Highlight special blocked cell
    if cell == 15:
        safe_addstr(stdscr, screen_y, screen_x, WALL_CHAR,
                    curses.color_pair(5) | curses.A_BOLD)
        return

    # Carve walls if open
    if not (cell & 1):  # North
        safe_addstr(stdscr, screen_y - 1, screen_x, PATH_CHAR)
    if not (cell & 2):  # East
        safe_addstr(stdscr, screen_y, screen_x + 1, PATH_CHAR)
    if not (cell & 4):  # South
        safe_addstr(stdscr, screen_y + 1, screen_x, PATH_CHAR)
    if not (cell & 8):  # West
        safe_addstr(stdscr, screen_y, screen_x - 1, PATH_CHAR)


def animate_generation(
    stdscr: Any,
    steps: List[Tuple[int, int, int, int]],
    height: int,
    width: int,
    entry_pos: Tuple[int, int],
    exit_pos: Tuple[int, int],
) -> None:
    """
    Animate maze generation cell by cell, replaying DFS wall-removal steps.

    Starts from a solid wall background and carves passages one step at a
    time, highlighting the DFS frontier with a cursor character so the
    exploration tree is clearly visible as it grows.

    Args:
        stdscr: curses window object
        steps: ordered list of (x1, y1, x2, y2) wall-removal events
        height: maze height in cells
        width: maze width in cells
        entry_pos: (x, y) entry coordinates
        exit_pos: (x, y) exit coordinates
    """
    # Wall bitmask constants (N=1, E=2, S=4, W=8)
    N, E, S, W = 1, 2, 4, 8

    stdscr.clear()
    canvas_height = 2 * height + 1
    canvas_width = 2 * width + 1

    # Fill solid wall background
    for cy in range(canvas_height):
        for cx in range(canvas_width):
            safe_addstr(stdscr, cy, cx, WALL_CHAR, curses.color_pair(1))

    # Draw header
    header_y = canvas_height + 1
    header_x = max(0, (canvas_width - len(HEADER_TEXT)) // 2)
    safe_addstr(stdscr, header_y, header_x, HEADER_TEXT,
                curses.color_pair(1) | curses.A_BOLD)
    stdscr.refresh()

    # Local wall state — starts fully walled (15 = N|E|S|W)
    local: List[List[int]] = [[15] * width for _ in range(height)]

    for x1, y1, x2, y2 in steps:
        dx = x2 - x1
        dy = y2 - y1

        # Update local wall state to reflect this removal
        if dx == 1:
            local[y1][x1] &= ~E
            local[y2][x2] &= ~W
        elif dx == -1:
            local[y1][x1] &= ~W
            local[y2][x2] &= ~E
        elif dy == 1:
            local[y1][x1] &= ~S
            local[y2][x2] &= ~N
        elif dy == -1:
            local[y1][x1] &= ~N
            local[y2][x2] &= ~S

        # Flash the newly-reached cell as the DFS frontier
        # safe_addstr(stdscr, 2 * y2 + 1, 2 * x2 + 1, CURSOR_CHAR,
        #             curses.color_pair(5) | curses.A_BOLD)
        # stdscr.refresh()
        # curses.napms(15)

        # Carve both affected cells
        draw_cell(stdscr, local, y1, x1)
        draw_cell(stdscr, local, y2, x2)
        stdscr.refresh()

    # Draw entry / exit markers
    entry_y, entry_x = 2 * entry_pos[1] + 1, 2 * entry_pos[0] + 1
    exit_y, exit_x = 2 * exit_pos[1] + 1, 2 * exit_pos[0] + 1
    safe_addstr(stdscr, entry_y, entry_x, ENTRY_CHAR,
                curses.color_pair(2) | curses.A_BOLD)
    safe_addstr(stdscr, exit_y, exit_x, EXIT_CHAR,
                curses.color_pair(3) | curses.A_BOLD)
    stdscr.refresh()
    curses.napms(200)  # Brief pause after generation completes


def draw_maze(
    stdscr: Any,
    maze: List[List[int]],
    entry_pos: Tuple[int, int],
    exit_pos: Tuple[int, int],
    solution: Optional[List[Tuple[int, int]]] = None,
    animate_solution: bool = False,
    animate_maze: bool = False,
) -> None:
    """
    Draw the full maze, entry/exit, header, and optionally the solution.

    Args:
        stdscr: curses window object
        maze: 2D maze grid
        entry_pos: (x, y) entry coordinates
        exit_pos: (x, y) exit coordinates
        solution: list of (x, y) coordinates for solution path
        animate_solution: whether to animate solution drawing
        animate_maze: whether to animate maze build
    """
    stdscr.clear()
    height = len(maze)
    width = len(maze[0])
    canvas_height = 2 * height + 1
    canvas_width = 2 * width + 1

    if animate_maze:
        # Phase 1: Curtain sweep — fill walls column by column with a bright
        # leading-edge highlight that settles to the normal wall colour.
        for x in range(canvas_width):
            for y in range(canvas_height):
                safe_addstr(stdscr, y, x, WALL_CHAR,
                            curses.color_pair(5) | curses.A_BOLD)
            stdscr.refresh()
            curses.napms(12)
            for y in range(canvas_height):
                safe_addstr(stdscr, y, x, WALL_CHAR, curses.color_pair(1))

        # Phase 2: Carve maze cells row by row; each cell briefly flashes
        # before being carved to give a "chisel" effect.
        for y in range(height):
            for x in range(width):
                screen_y = 2 * y + 1
                screen_x = 2 * x + 1
                safe_addstr(stdscr, screen_y, screen_x, PATH_CHAR,
                            curses.color_pair(5) | curses.A_BOLD)
                stdscr.refresh()
                curses.napms(20)
                draw_cell(stdscr, maze, y, x)
            stdscr.refresh()
            curses.napms(15)

        stdscr.refresh()
        curses.napms(120)  # Brief pause to appreciate the completed maze
    else:
        # Instant fill and carve (no animation)
        for y in range(canvas_height):
            for x in range(canvas_width):
                safe_addstr(stdscr, y, x, WALL_CHAR, curses.color_pair(1))
        for y in range(height):
            for x in range(width):
                draw_cell(stdscr, maze, y, x)

    # Draw entry/exit
    entry_y, entry_x = 2 * entry_pos[1] + 1, 2 * entry_pos[0] + 1
    exit_y, exit_x = 2 * exit_pos[1] + 1, 2 * exit_pos[0] + 1
    safe_addstr(stdscr, entry_y, entry_x, ENTRY_CHAR,
                curses.color_pair(2) | curses.A_BOLD)
    safe_addstr(stdscr, exit_y, exit_x, EXIT_CHAR,
                curses.color_pair(3) | curses.A_BOLD)

    # Draw header
    header_y = canvas_height + 1
    header_x = max(0, (canvas_width - len(HEADER_TEXT)) // 2)
    safe_addstr(stdscr, header_y, header_x, HEADER_TEXT,
                curses.color_pair(1) | curses.A_BOLD)

    # Draw solution path
    if solution:
        path_positions = _solution_screen_positions(solution)
        if animate_solution:
            # A moving cursor (CURSOR_CHAR) travels the full path — including
            # the corridor cells between maze cells — leaving solution markers
            # as a connected trail behind it.
            for sol_y, sol_x in path_positions:
                safe_addstr(stdscr, sol_y, sol_x, SOLUTION_CHAR,
                            curses.color_pair(4) | curses.A_BOLD)
                stdscr.refresh()
                curses.napms(40)
            stdscr.refresh()
        else:
            for sol_y, sol_x in path_positions:
                safe_addstr(stdscr, sol_y, sol_x, SOLUTION_CHAR,
                            curses.color_pair(4) | curses.A_BOLD)

    stdscr.refresh()


# ---------- Menu ----------
MENU_ITEMS = [
    "1 - Re-generate maze",
    "2 - Show / Animate solution path",
    "3 - Rotate maze colors",
    "4 - change algo",
    "5 - Quit",
]


def draw_menu(stdscr: Any, maze_height: int) -> None:
    """
    Draw the menu under the maze.

    Args:
        stdscr: curses window object
        maze_height: number of rows in the maze
    """
    canvas_height = 2 * maze_height + 1
    start_y = canvas_height + 3
    start_x = 2

    for i, item in enumerate(MENU_ITEMS):
        safe_addstr(stdscr, start_y + i, start_x, item)

    safe_addstr(stdscr, start_y + len(MENU_ITEMS) + 1,
                start_x, "Choice (1-5): ")
    stdscr.refresh()
